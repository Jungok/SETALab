# SETALab
# AuLoRa

오로라 사용을 위해서는 온라인 라이센스 구매가 필요합니다. 

  2018년 오로라 온라인 라이센스 사용료
	
  1개월 : 30만원  1년 : 300만원
	
  Contact :  www.setalab.com help@setalab.com
